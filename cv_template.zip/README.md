# Welcome to my personal page

1. 本地环境安装
    安装node [官网](https://nodejs.org/en)
    安装本项目依赖：npm install
    本地修改：npm run dev
    
2. 本地更新文件和信息
    1. 图像等文件放在src\assets\
    2. 基本信息在src\App.jsx
    3. twitter等链接没有就注释掉相应的行（line157 -160 in App.jsx）
    4. 调整主题在 tailwindcss.config.js，调整第18行themes中主题的顺序即可，更多主题见[daisyUI 主题](https://daisyui.com/docs/themes/?lang=zh_cn)

3. 上传到github并用pages部署
    [参考教程](https://www.geeksforgeeks.org/deployment-of-react-application-using-github-pages/)